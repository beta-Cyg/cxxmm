#ifndef SPLIT_H
#define SPLIT_H

#include<vector>
#include<string>

namespace cygnus{
	std::vector<std::string> split(std::string str,const std::string& delimiter);
}

#endif
