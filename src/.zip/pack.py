#!/usr/bin/python3

import os,os.path
import zipfile
import sys


def zip_dir(dirname,zipfilename):
	filelist = []
	if os.path.isfile(dirname):
		filelist.append(dirname)
	else:
		for root, dirs, files in os.walk(dirname):
			for name in files:
				filelist.append(os.path.join(root, name))
	zf = zipfile.ZipFile(zipfilename, "w", zipfile.zlib.DEFLATED)
	for tar in filelist:
		arcname = tar[len(dirname):]
		#print arcname
		zf.write(tar,arcname)
	zf.close()


#debugging
def unzip_file(zipfilename, unziptodir):
	if not os.path.exists(unziptodir):
		os.mkdir(unziptodir, 755)
	zfobj = zipfile.ZipFile(zipfilename)
	for name in zfobj.namelist():
		name = name.replace('\\','/')
		if name.endswith('/'):
			os.mkdir(os.path.join(unziptodir, name))
		else:
			ext_filename = os.path.join(unziptodir, name)
			ext_dir = os.path.dirname(ext_filename)
			if not os.path.exists(ext_dir):
				os.mkdir(ext_dir, 755)
			outfile = open(ext_filename, "wb")
			outfile.write(zfobj.read(name))
			outfile.close()

if __name__ == '__main__':
	if sys.argv == 1 or sys.argv == 2:
		exit(1)
	else:
		if sys.argv[1] == "pack":
			print(sys.argv[2], sys.argv[2]+".zip")
			zip_dir(sys.argv[2], sys.argv[2]+".zip")
		elif sys.argv[1] == "unpack":
			unzip_file(sys.argv[2], sys.argv[2].rstrip(".zip"))
		else:
			exit(1)
	#zip_dir(r"cxxmm", r"cxxmm.zip")
	#unzip_file(r"cxxmm.zip", r"CM")
